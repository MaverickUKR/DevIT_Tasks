export const DUMMY_BASE_URL = 'https://dummyjson.com';
